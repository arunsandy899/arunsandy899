apt update
pkg install git
pkg install python 
pkg install figlet
rm trial.py trial*
wget -q "https://raw.githubusercontent.com/Daksh98765/Daksh98765/main/trial.py"
clear
python trial.py
